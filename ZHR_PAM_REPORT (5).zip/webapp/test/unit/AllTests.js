sap.ui.define([
	"com/pd/PamReport/ZHR_PAM_REPORT/test/unit/controller/Main.controller"
], function () {
	"use strict";
});