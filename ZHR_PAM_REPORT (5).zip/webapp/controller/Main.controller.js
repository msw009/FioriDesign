sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/Label",
	// "sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	// "sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/FilterOperator",
	"sap/ui/comp/smartvariants/PersonalizableInfo"
	// ], function (Controller, JSONModel, Label, History, Filter, MessageToast, MessageBox, FilterOperator, PersonalizableInfo) {
], function (Controller, JSONModel, Label, Filter, MessageBox, FilterOperator, PersonalizableInfo) {
	"use strict";

	return Controller.extend("com.pd.PamReport.ZHR_PAM_REPORT.controller.Main", {
		onInit: function () {
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");

			// UI5 Filter/Variant specific logic
			this.getView().setModel(oJSONModel);
			this.applyData = this.applyData.bind(this);
			this.fetchData = this.fetchData.bind(this);
			this.getFiltersWithValues = this.getFiltersWithValues.bind(this);

			this.oSmartVariantManagement = this.getView().byId("svm");
			this.oExpandedLabel = this.getView().byId("expandedLabel");
			this.oSnappedLabel = this.getView().byId("snappedLabel");
			this.oFilterBar = this.getView().byId("filterBar");
			this.oTable = this.getView().byId("table");

			this.oFilterBar.registerFetchData(this.fetchData);
			this.oFilterBar.registerApplyData(this.applyData);
			this.oFilterBar.registerGetFiltersWithValues(this.getFiltersWithValues);

			var oPersInfo = new PersonalizableInfo({
				type: "filterBar",
				keyName: "persistencyKey",
				dataSource: "",
				control: this.oFilterBar
			});
			this.oSmartVariantManagement.addPersonalizableControl(oPersInfo);
			this.oSmartVariantManagement.initialise(function () {}, this.oFilterBar);
			// End of filter/Variant logic

			sap.ui.core.BusyIndicator.show(0);
			var that = this;

			// called for CountryListSet combo box model binding
			oModel.read("/OrgListSet", {
				success: function (r) {
					sap.ui.core.BusyIndicator.hide();
					oJSONModel.setProperty("/ViewDrpdwn", r.results);

					// for (var v = 0; v < oJSONModel.getProperty("/ViewDrpdwn").length; v++) {
					// 	if (oJSONModel.getProperty("/ViewDrpdwn")[v].DefaultOrgKey === "X") {
					// 		var sOrgKey = oJSONModel.getProperty("/ViewDrpdwn")[v].OrgKey;
					// 		oJSONModel.setProperty("/sOrgKey", sOrgKey);
					// 		break;
					// 	}
					// }
					var sOrgKey = that.byId("cmbSel").getSelectedKeys()[0];

					var aFilters = [new Filter("OrgKey", "EQ", sOrgKey)];
					// called for the DEFAULT Report for the FIRST TIME
					oModel.read("/MATRIXSet", {
						filters: aFilters,
						success: function (rDefault) {
							var oJSON2 = new JSONModel(rDefault);
							// Set model for the view based on JSON model of response
							that.getView().setModel(oJSON2, "zPAMOutput");
							// Refresh model
							that.getView().getModel("zPAMOutput").refresh();

							oModel.read("/URLSet", {
								success: function (rURL) {
									oJSONModel.setProperty("/Link", rURL.results[0].Link);
								},
								error: function () {
									sap.ui.core.BusyIndicator.hide();
								}
							});
						},
						error: function () {
							sap.ui.core.BusyIndicator.hide();
						}
					});
				}
			});
		},

		fetchData: function () {
			var aData = this.oFilterBar.getAllFilterItems().reduce(function (aResult, oFilterItem) {
				aResult.push({
					groupName: oFilterItem.getGroupName(),
					fieldName: oFilterItem.getName(),
					// fieldData: "USA"
					fieldData: oFilterItem.getControl().getSelectedKeys()
				});
				return aResult;
			}, []);

			return aData;
		},

		applyData: function (aData) {
			aData.forEach(function (oDataObject) {
				var oControl = this.oFilterBar.determineControlByName(oDataObject.fieldName, oDataObject.groupName);
				oControl.setSelectedKeys(oDataObject.fieldData);
			}, this);
		},

		getFiltersWithValues: function () {
			var aFiltersWithValue = this.oFilterBar.getFilterGroupItems().reduce(function (aResult, oFilterGroupItem) {
				var oControl = oFilterGroupItem.getControl();

				if (oControl && oControl.getSelectedKeys && oControl.getSelectedKeys().length > 0) {
					aResult.push(oFilterGroupItem);
				}

				return aResult;
			}, []);

			return aFiltersWithValue;
		},

		onSelectionChange: function (oEvent) {
			this.oSmartVariantManagement.currentVariantSetModified(true);
			this.oFilterBar.fireFilterChange(oEvent);
		},

		onFilterChange: function () {
			this._updateLabelsAndTable();
		},

		onAfterVariantLoad: function () {
			this._updateLabelsAndTable();
		},
		getFormattedSummaryText: function () {
			var aFiltersWithValues = this.oFilterBar.retrieveFiltersWithValues();

			if (aFiltersWithValues.length === 0) {
				return "No filters active";
			}

			if (aFiltersWithValues.length === 1) {
				return aFiltersWithValues.length + " filter active: " + aFiltersWithValues.join(", ");
			}

			return aFiltersWithValues.length + " filters active: " + aFiltersWithValues.join(", ");
		},

		getFormattedSummaryTextExpanded: function () {
			var aFiltersWithValues = this.oFilterBar.retrieveFiltersWithValues();

			if (aFiltersWithValues.length === 0) {
				return "No filters active";
			}

			// var sText = aFiltersWithValues.length + " filters active",
			// aNonVisibleFiltersWithValues = this.oFilterBar.retrieveNonVisibleFiltersWithValues();

			if (aFiltersWithValues.length === 1) {
				var sText = aFiltersWithValues.length + " filter active";
			}

			// if (aNonVisibleFiltersWithValues && aNonVisibleFiltersWithValues.length > 0) {
			// 	sText += " (" + aNonVisibleFiltersWithValues.length + " hidden)";
			// }

			return sText;
		},

		_updateLabelsAndTable: function () {
			this.oExpandedLabel.setText(this.getFormattedSummaryTextExpanded());
			this.oSnappedLabel.setText(this.getFormattedSummaryText());
			// this.oTable.setShowOverlay(true);
		},

		onExit: function () {
			this.oModel = null;
			this.oSmartVariantManagement = null;
			this.oExpandedLabel = null;
			this.oSnappedLabel = null;
			this.oFilterBar = null;
			this.oTable = null;
		},

		handleSelectionChange: function (oEvent) {
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			var oJSONModel = this.getOwnerComponent().getModel("json");
			// var sOrgKey = this.byId("cmbSel").getSelectedKey();
			var sOrgKey = this.byId("cmbSel").getSelectedKeys()[0];

			//Do not let the user select more than one selection on the drop-down
			if (this.byId("cmbSel").getSelectedKeys()[1]) {
				MessageBox.error("Please select ONLY ONE region/country");
				return;
			} else {
				// Do nothing. Let the process run as usual
			}

			oJSONModel.setProperty("/sOrgKey", sOrgKey);
			var aFilters = [new Filter("OrgKey", "EQ", sOrgKey)];
			// called for FRESH report upon drop-down selection value
			oModel.read("/MATRIXSet", {
				filters: aFilters,
				success: function (r) {
					// Declare local model to convert OData response to JSON
					var oJSON2 = new JSONModel(r);
					// Set model for the view based on JSON model of response
					that.getView().setModel(oJSON2, "zPAMOutput");
					// Refresh model
					that.getView().getModel("zPAMOutput").refresh();
				},
				error: function () {
					sap.ui.core.BusyIndicator.hide();
				}

			});
			// this.oTable.getBinding("items").filter(aFilters);
			// this.oTable.setShowOverlay(false);
		},

		oncellClick: function (oEvent) {
			//To get the Column heading name of the selected cell/row (it will always be the 1st record(i.e 0th record), but we need to retrieve the Column# here first)
			var sColumnIndex = oEvent.getParameter("columnIndex");
			sColumnIndex = +sColumnIndex + +1;
			var sField = "Field" + sColumnIndex;
			var sColumnHeading = this.getView().getModel("zPAMOutput").getProperty("/results")[0][sField];

			//To get the Row heading (first field name of the selected cell/row), (it will always be the Field1, but we need to retrieve the Row# here first)
			var sRowIndex = oEvent.getParameter("rowIndex");
			var sRowHeading = this.getView().getModel("zPAMOutput").getProperty("/results")[sRowIndex].Field1;
			// var sValue = oEvent.getParameter("cellControl").mBindingInfos.text.binding.oValue;
			var sValue = this.getView().getModel("zPAMOutput").getProperty("/results")[sRowIndex][sField];
			// var sOrgKey = this.byId("cntryComb").getSelectedKey();
			var sOrgKey = this.byId("cmbSel").getSelectedKeys()[0];

			if (sValue) {
				if ((sRowHeading === "Total" || sColumnHeading === "Total") ||
					(sRowIndex === 0) ||
					(sColumnIndex === 1)) {
					MessageBox.information("This navigation is not possible");
					return;
				} else {

					// MessageBox.information("You have clicked on " + sRowHeading + " and" + " " + sColumnHeading);
				}
			} else {
				MessageBox.information("This navigation is not possible");
			}

			var oJSONModel = this.getOwnerComponent().getModel("json");
			var navUrl = oJSONModel.getProperty("/Link");
			//Begin of temp
			// for (var v = 0; v < oJSONModel.getProperty("/ViewDrpdwn").length; v++) {
			// 	if (oJSONModel.getProperty("/ViewDrpdwn")[v].OrgKey === sOrgKey) {
			// 		var sOrgKeyText = oJSONModel.getProperty("/ViewDrpdwn")[v].Text;
			// 		break;
			// 	}
			// }
			//End of temp
			var scompanyCode = "";
			if (sOrgKey === 'CAN') {
				scompanyCode = '1100';
			} else {
				scompanyCode = '2100';
			}
			// navUrl = navUrl + '&country=' + sOrgKey + '&title=' + sRowHeading + '&currentJob=' + sColumnHeading;
			navUrl = navUrl + '&companyCode=' + scompanyCode + '&title=' + sRowHeading + '&currentJob=' + sColumnHeading;
			sap.m.URLHelper.redirect(navUrl, true);

			// var oCrossAppNav = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
			// 	"CrossApplicationNavigation");
			// var hrefForEmployeeListdisplay = (oCrossAppNav &&
			// 	oCrossAppNav.hrefForExternal({
			// 		target: {
			// 			semanticObject: "User",
			// 			action: "display"
			// 		},
			// 		params: {
			// 			"title": sRowHeading,
			// 			"currentJob": sColumnHeading,
			// 			"country": sOrgKey
			// 		}
			// 	})) || "";
			// var navUrl = window.location.href.split("#")[0] + hrefForEmployeeListdisplay;
			// sap.m.URLHelper.redirect(navUrl, true);

			// var navUrl =
			// 	"https://fiori-cloud-798g7cgu.launchpad.cfapps.us20.hana.ondemand.com/site?siteId=64f85781-df9c-454b-b885-4b87b8bee3c5#User-display?sap-ui-app-id-hint=dd93d3e6-5bda-4cdd-8379-379bd8dcf7f8";

			// var oCrossAppNav = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService("CrossApplicationNavigation");
			// var href_For_EmployeeList_display = (oCrossAppNav &&
			// 	oCrossAppNav.toExternal({
			// 		target: {
			// 			semanticObject: "User",
			// 			action: "display"
			// 		},
			// 		params: {
			// 			"title": sRowHeading,
			// 			"currentJob": sColumnHeading,
			// 			"country": sOrgKey
			// 		}
			// 	})) || "";

			// sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {

			// 	oService.hrefForExternalAsync({
			// 		target: {
			// 			semanticObject: "User",
			// 			action: "display"
			// 		},
			// 		params: {
			// 			"title": sRowHeading,
			// 			"currentJob": sColumnHeading
			// 		}
			// 	}).then(function (sHref) {
			// 		// Place sHref somewhere in the DOM
			// 	});
			// });

		}
	});
});